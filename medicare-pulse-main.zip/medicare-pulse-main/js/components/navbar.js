import { Auth } from '../auth.js';

export function renderNavbar(currentRoute = 'home') {
  const user = Auth.getCurrentUser();
  const isPatient = Auth.isPatient();
  const isAdmin = Auth.isAdmin();

  return `
    <div class="container nav-container">
      <!-- Brand Logo -->
      <a href="#home" class="brand-logo" id="nav-brand-logo">
        <div class="brand-icon">✚</div>
        <div>
          <span>MediCare</span><span style="color: var(--primary);">Pulse</span>
        </div>
      </a>

      <!-- Navigation Links -->
      <ul class="nav-links">
        <li>
          <a href="#home" class="nav-link ${currentRoute === 'home' ? 'active' : ''}" id="nav-link-home">Home</a>
        </li>
        <li>
          <a href="#doctors" class="nav-link ${currentRoute === 'doctors' ? 'active' : ''}" id="nav-link-doctors">Doctors</a>
        </li>
        ${isPatient ? `
          <li>
            <a href="#patient-dashboard" class="nav-link ${currentRoute === 'patient-dashboard' ? 'active' : ''}" id="nav-link-patient-dashboard">
              My Appointments
            </a>
          </li>
        ` : ''}
        ${isAdmin ? `
          <li>
            <a href="#admin-dashboard" class="nav-link ${currentRoute === 'admin-dashboard' ? 'active' : ''}" id="nav-link-admin-dashboard">
              Admin Console
            </a>
          </li>
        ` : ''}
      </ul>

      <!-- User Session Actions -->
      <div class="nav-actions">
        ${user ? `
          <div class="user-badge">
            <span>👤 ${user.name}</span>
            <span class="user-badge-role">${user.role}</span>
          </div>
          <button class="btn btn-secondary btn-sm" id="btn-logout" title="Sign out of current account">
            Sign Out
          </button>
        ` : `
          <a href="#auth" class="btn btn-primary btn-sm" id="nav-login-btn">
            Sign In / Register
          </a>
        `}
      </div>
    </div>
  `;
}

export function initNavbarEvents() {
  document.getElementById('btn-logout')?.addEventListener('click', () => {
    Auth.logout();
    window.dispatchEvent(new CustomEvent('toast:show', {
      detail: { message: 'You have been signed out.', type: 'info' }
    }));
    window.location.hash = '#home';
  });
}

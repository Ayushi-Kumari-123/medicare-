import { Auth } from '../auth.js';

export function renderAuth() {
  return `
    <div class="container">
      <div class="auth-container">
        <!-- Tabs -->
        <div class="auth-tabs" id="auth-tab-buttons">
          <div class="auth-tab active" data-tab="patient-login" id="tab-patient-login">
            Patient Login
          </div>
          <div class="auth-tab" data-tab="patient-register" id="tab-patient-register">
            Patient Register
          </div>
          <div class="auth-tab" data-tab="admin-login" id="tab-admin-login">
            Admin Login
          </div>
        </div>

        <div class="auth-body">
          <!-- Alert Box -->
          <div id="auth-alert" style="display: none; padding: 0.75rem 1rem; border-radius: var(--radius-md); font-size: 0.875rem; margin-bottom: 1.25rem;"></div>

          <!-- Patient Login Form -->
          <form id="form-patient-login">
            <div class="form-group">
              <label class="form-label" for="pl-email">Patient Email</label>
              <input type="email" id="pl-email" class="form-control" placeholder="patient@example.com" required />
            </div>

            <div class="form-group">
              <label class="form-label" for="pl-password">Password</label>
              <input type="password" id="pl-password" class="form-control" placeholder="••••••••••••" required />
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 0.75rem;" id="pl-submit-btn">
              Sign In to Patient Portal
            </button>
          </form>

          <!-- Patient Register Form -->
          <form id="form-patient-register" style="display: none;">
            <div class="form-group">
              <label class="form-label" for="pr-name">Full Name</label>
              <input type="text" id="pr-name" class="form-control" placeholder="John Doe" required />
            </div>

            <div class="form-group">
              <label class="form-label" for="pr-email">Email Address</label>
              <input type="email" id="pr-email" class="form-control" placeholder="john@example.com" required />
            </div>

            <div class="form-group">
              <label class="form-label" for="pr-password">Create Password</label>
              <input type="password" id="pr-password" class="form-control" placeholder="Minimum 6 characters" minlength="6" required />
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 0.75rem;" id="pr-submit-btn">
              Create Free Account & Sign In
            </button>
          </form>

          <!-- Admin Login Form -->
          <form id="form-admin-login" style="display: none;">
            <div class="form-group">
              <label class="form-label" for="al-email">Administrator Email</label>
              <input type="email" id="al-email" class="form-control" placeholder="admin@medicare.com" required value="admin@medicare.com" />
            </div>

            <div class="form-group">
              <label class="form-label" for="al-password">Administrator Password</label>
              <input type="password" id="al-password" class="form-control" placeholder="••••••••••••" required />
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 0.75rem; background: linear-gradient(135deg, #0f172a, #334155);" id="al-submit-btn">
              Access Admin Console
            </button>
          </form>

          <!-- Tip Box -->
          <div class="demo-credentials-box">
            <h4>🔥 Firebase Connected</h4>
            <p style="color: var(--text-muted); font-size: 0.8rem; margin-top: 0.25rem;">
              New patients can register directly using the <strong>Patient Register</strong> tab. Accounts are saved in your live Firebase Authentication and Firestore!
            </p>
          </div>
        </div>
      </div>
    </div>
  `;
}

export function initAuthEvents() {
  const tabs = document.querySelectorAll('.auth-tab');
  const formPL = document.getElementById('form-patient-login');
  const formPR = document.getElementById('form-patient-register');
  const formAL = document.getElementById('form-admin-login');
  const alertBox = document.getElementById('auth-alert');

  const showAlert = (msg, isError = true) => {
    if (!alertBox) return;
    alertBox.textContent = msg;
    alertBox.style.display = 'block';
    alertBox.style.backgroundColor = isError ? 'var(--status-cancelled-bg)' : 'var(--status-confirmed-bg)';
    alertBox.style.color = isError ? 'var(--status-cancelled)' : 'var(--status-confirmed)';
    alertBox.style.border = `1px solid ${isError ? '#fecaca' : '#a7f3d0'}`;
  };

  const switchTab = (tabName) => {
    tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === tabName));
    formPL.style.display = tabName === 'patient-login' ? 'block' : 'none';
    formPR.style.display = tabName === 'patient-register' ? 'block' : 'none';
    formAL.style.display = tabName === 'admin-login' ? 'block' : 'none';
    if (alertBox) alertBox.style.display = 'none';
  };

  tabs.forEach(t => {
    t.addEventListener('click', () => switchTab(t.dataset.tab));
  });

  // Patient Login Submit
  formPL?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('pl-email').value;
    const password = document.getElementById('pl-password').value;
    const submitBtn = document.getElementById('pl-submit-btn');

    try {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Authenticating...';
      const res = await Auth.login(email, password, 'patient');
      if (res.success) {
        window.dispatchEvent(new CustomEvent('toast:show', { detail: { message: `Welcome back, ${res.user.name}!`, type: 'success' } }));
        const returnUrl = sessionStorage.getItem('returnUrl');
        if (returnUrl) {
          sessionStorage.removeItem('returnUrl');
          window.location.hash = returnUrl;
        } else {
          window.location.hash = '#patient-dashboard';
        }
      } else {
        showAlert(res.error, true);
      }
    } catch (err) {
      showAlert(err.message, true);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Sign In to Patient Portal';
    }
  });

  // Patient Register Submit
  formPR?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('pr-name').value;
    const email = document.getElementById('pr-email').value;
    const password = document.getElementById('pr-password').value;
    const submitBtn = document.getElementById('pr-submit-btn');

    try {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Creating account...';
      const res = await Auth.register(name, email, password);
      if (res.success) {
        window.dispatchEvent(new CustomEvent('toast:show', { detail: { message: `Account created in Firebase! Welcome, ${res.user.name}.`, type: 'success' } }));
        window.location.hash = '#patient-dashboard';
      } else {
        showAlert(res.error, true);
      }
    } catch (err) {
      showAlert(err.message, true);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Create Free Account & Sign In';
    }
  });

  // Admin Login Submit
  formAL?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('al-email').value;
    const password = document.getElementById('al-password').value;
    const submitBtn = document.getElementById('al-submit-btn');

    try {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Verifying admin credentials...';
      const res = await Auth.login(email, password, 'admin');
      if (res.success) {
        window.dispatchEvent(new CustomEvent('toast:show', { detail: { message: 'Logged in to Admin Console.', type: 'success' } }));
        window.location.hash = '#admin-dashboard';
      } else {
        showAlert(res.error, true);
      }
    } catch (err) {
      showAlert(err.message, true);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Access Admin Console';
    }
  });
}

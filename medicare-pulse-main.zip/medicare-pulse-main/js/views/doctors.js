import { Store } from '../store.js';

export function renderDoctorList(initialSearch = '', initialSpecialty = '') {
  const specialties = ['All', 'Cardiology', 'Dermatology', 'Neurology', 'Pediatrics', 'Orthopedics', 'General Medicine'];

  return `
    <div class="container">
      <div style="margin-bottom: 2rem;">
        <h1 style="font-size: 2.25rem; font-weight: 800; color: var(--text-main); margin-bottom: 0.5rem;">
          Find a Doctor
        </h1>
        <p style="color: var(--text-muted); font-size: 1.05rem;">
          Browse our certified physicians and book consultation slots instantly.
        </p>
      </div>

      <!-- Filter / Search Toolbar -->
      <div style="background: #ffffff; padding: 1.25rem; border-radius: var(--radius-lg); border: 1px solid var(--border-color); box-shadow: var(--shadow-sm); margin-bottom: 2rem; display: flex; flex-wrap: wrap; gap: 1rem; align-items: center; justify-content: space-between;">
        <div style="flex: 1; min-width: 260px; position: relative;">
          <input 
            type="text" 
            id="doc-search-input" 
            class="form-control" 
            placeholder="Search by doctor name or specialty..."
            value="${initialSearch}" 
          />
        </div>

        <div style="display: flex; gap: 0.75rem; align-items: center;">
          <label style="font-size: 0.875rem; font-weight: 600; color: var(--text-muted); white-space: nowrap;">
            Filter Specialty:
          </label>
          <select id="doc-specialty-select" class="form-control" style="width: auto; min-width: 180px; padding: 0.6rem 0.85rem;">
            ${specialties.map(s => `
              <option value="${s === 'All' ? '' : s}" ${initialSpecialty === s || (initialSpecialty === '' && s === 'All') ? 'selected' : ''}>
                ${s}
              </option>
            `).join('')}
          </select>
        </div>
      </div>

      <!-- Doctor Cards Container -->
      <div id="doctor-results-grid" class="doctor-grid">
        <!-- Rendered by initDoctorListEvents -->
      </div>
    </div>
  `;
}

export function initDoctorListEvents(initialSearch = '', initialSpecialty = '') {
  const searchInput = document.getElementById('doc-search-input');
  const specialtySelect = document.getElementById('doc-specialty-select');
  const gridContainer = document.getElementById('doctor-results-grid');

  const renderGrid = () => {
    if (!gridContainer) return;

    const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const selectedSpecialty = specialtySelect ? specialtySelect.value : '';

    const allDoctors = Store.getDoctors();
    const filtered = allDoctors.filter(doc => {
      const matchesSearch = doc.name.toLowerCase().includes(searchTerm) || doc.specialization.toLowerCase().includes(searchTerm);
      const matchesSpecialty = !selectedSpecialty || doc.specialization.toLowerCase() === selectedSpecialty.toLowerCase();
      return matchesSearch && matchesSpecialty;
    });

    if (filtered.length === 0) {
      gridContainer.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 4rem 2rem; background: #ffffff; border-radius: var(--radius-lg); border: 1px dashed var(--border-color);">
          <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">🔍</div>
          <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.25rem;">No doctors match your search</h3>
          <p style="color: var(--text-muted); font-size: 0.95rem; margin-bottom: 1.25rem;">Try adjusting your query or resetting your specialty filters.</p>
          <button id="btn-reset-filters" class="btn btn-secondary btn-sm">Reset Filters</button>
        </div>
      `;
      document.getElementById('btn-reset-filters')?.addEventListener('click', () => {
        if (searchInput) searchInput.value = '';
        if (specialtySelect) specialtySelect.value = '';
        renderGrid();
      });
      return;
    }

    gridContainer.innerHTML = filtered.map(doc => `
      <div class="doctor-card">
        <div class="doctor-card-top">
          <div class="doctor-avatar">${doc.avatar || 'DR'}</div>
          <div class="doctor-meta">
            <h3>${doc.name}</h3>
            <span class="doctor-spec">${doc.specialization}</span>
            <div class="doctor-rating">★ ${(doc.rating || 4.9).toFixed(1)} (${doc.experienceYears || 10}+ yrs exp)</div>
          </div>
        </div>

        <p style="font-size: 0.875rem; color: var(--text-muted); margin-bottom: 1rem; line-height: 1.45;">
          ${doc.bio || 'Compassionate healthcare professional dedicated to patient-centered clinical care and preventative therapies.'}
        </p>

        <div class="doctor-slots-title">Available Time Slots:</div>
        <div class="slot-tags">
          ${(doc.availableSlots || []).map(slot => `<span class="slot-tag">${slot}</span>`).join('')}
        </div>

        <div class="doctor-card-footer">
          <span style="font-size: 0.85rem; color: var(--text-muted); font-weight: 500;">
            ${(doc.availableSlots || []).length} slots available
          </span>
          <a href="#book?doctorId=${doc.id}" class="btn btn-primary btn-sm" id="book-doctor-${doc.id}">
            Book Appointment
          </a>
        </div>
      </div>
    `).join('');
  };

  searchInput?.addEventListener('input', renderGrid);
  specialtySelect?.addEventListener('change', renderGrid);
  window.addEventListener('store:updated', renderGrid);

  // Initial render
  renderGrid();
}

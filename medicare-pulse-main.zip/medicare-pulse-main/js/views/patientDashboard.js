import { Store } from '../store.js';
import { Auth } from '../auth.js';

export function renderPatientDashboard() {
  const user = Auth.getCurrentUser();

  if (!user || user.role !== 'patient') {
    return `
      <div class="container" style="text-align: center; padding: 4rem 1rem;">
        <div style="font-size: 3rem; margin-bottom: 1rem;">🔒</div>
        <h2 style="font-size: 1.75rem; font-weight: 800; margin-bottom: 0.5rem;">Patient Access Only</h2>
        <p style="color: var(--text-muted); margin-bottom: 2rem;">Please sign in with your patient account to view your appointment history.</p>
        <a href="#auth" class="btn btn-primary">Sign In / Register</a>
      </div>
    `;
  }

  const allAppointments = Store.getAppointmentsByPatient(user.id);
  const pendingCount = allAppointments.filter(a => a.status === 'Pending').length;
  const confirmedCount = allAppointments.filter(a => a.status === 'Confirmed').length;
  const cancelledCount = allAppointments.filter(a => a.status === 'Cancelled').length;

  return `
    <div class="container">
      <!-- Welcome Header -->
      <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 1rem; margin-bottom: 2rem;">
        <div>
          <div style="font-size: 0.85rem; font-weight: 700; color: var(--primary); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.25rem;">
            Patient Portal (Live Cloud Firestore)
          </div>
          <h1 style="font-size: 2.25rem; font-weight: 800; color: var(--text-main);">
            Welcome back, ${user.name}!
          </h1>
          <p style="color: var(--text-muted); font-size: 0.95rem;">
            Account Email: <strong style="color: var(--text-main);">${user.email}</strong>
          </p>
        </div>

        <div>
          <a href="#doctors" class="btn btn-primary" id="btn-patient-book-new">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
            Book New Appointment
          </a>
        </div>
      </div>

      <!-- Quick Metrics -->
      <div class="dashboard-metrics">
        <div class="metric-card">
          <div class="metric-icon metric-blue">📅</div>
          <div>
            <div class="metric-val" id="patient-metric-total">${allAppointments.length}</div>
            <div class="metric-desc">Total Bookings</div>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon metric-green">✓</div>
          <div>
            <div class="metric-val" id="patient-metric-confirmed">${confirmedCount}</div>
            <div class="metric-desc">Confirmed / Active</div>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon metric-amber">⏳</div>
          <div>
            <div class="metric-val" id="patient-metric-pending">${pendingCount}</div>
            <div class="metric-desc">Pending Confirmation</div>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon metric-purple">✕</div>
          <div>
            <div class="metric-val" id="patient-metric-cancelled">${cancelledCount}</div>
            <div class="metric-desc">Cancelled Appointments</div>
          </div>
        </div>
      </div>

      <!-- Appointments List Table -->
      <div class="table-card">
        <div class="table-header">
          <div>
            <h2 style="font-size: 1.25rem; font-weight: 800; color: var(--text-main);">My Appointments</h2>
            <p style="color: var(--text-muted); font-size: 0.85rem;">Live updates synced in real-time with Firestore</p>
          </div>

          <div style="display: flex; gap: 0.5rem; align-items: center;">
            <label style="font-size: 0.85rem; font-weight: 600; color: var(--text-muted);">Status Filter:</label>
            <select id="patient-status-filter" class="form-control" style="width: auto; padding: 0.4rem 0.75rem; font-size: 0.85rem;">
              <option value="ALL">All Statuses</option>
              <option value="Pending">Pending</option>
              <option value="Confirmed">Confirmed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>
        </div>

        <div class="table-responsive">
          <table class="custom-table" id="patient-appointments-table">
            <thead>
              <tr>
                <th>Doctor & Specialization</th>
                <th>Date & Time</th>
                <th>Status</th>
                <th>Notes / Symptoms</th>
                <th style="text-align: right;">Action</th>
              </tr>
            </thead>
            <tbody id="patient-appointments-tbody">
              <!-- Rendered via JS -->
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
}

export function initPatientDashboardEvents() {
  const user = Auth.getCurrentUser();
  if (!user || user.role !== 'patient') return;

  const tbody = document.getElementById('patient-appointments-tbody');
  const statusFilter = document.getElementById('patient-status-filter');

  const renderTable = () => {
    if (!tbody) return;
    const filter = statusFilter ? statusFilter.value : 'ALL';
    let appointments = Store.getAppointmentsByPatient(user.id);

    // Update dynamic metric counters
    const pendingCount = appointments.filter(a => a.status === 'Pending').length;
    const confirmedCount = appointments.filter(a => a.status === 'Confirmed').length;
    const cancelledCount = appointments.filter(a => a.status === 'Cancelled').length;

    const elTotal = document.getElementById('patient-metric-total');
    const elConf = document.getElementById('patient-metric-confirmed');
    const elPend = document.getElementById('patient-metric-pending');
    const elCanc = document.getElementById('patient-metric-cancelled');

    if (elTotal) elTotal.textContent = appointments.length;
    if (elConf) elConf.textContent = confirmedCount;
    if (elPend) elPend.textContent = pendingCount;
    if (elCanc) elCanc.textContent = cancelledCount;

    if (filter !== 'ALL') {
      appointments = appointments.filter(a => a.status === filter);
    }

    if (appointments.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center; padding: 3rem 1rem; color: var(--text-muted);">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">📋</div>
            <p style="font-size: 1rem; font-weight: 600;">No appointments found ${filter !== 'ALL' ? `for status "${filter}"` : 'yet'}.</p>
            <a href="#doctors" class="btn btn-primary btn-sm" style="margin-top: 1rem;">Find and Book a Doctor</a>
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = appointments.map(apt => {
      const doctor = Store.getDoctorById(apt.doctorId) || { name: 'Specialist', specialization: 'General', id: '' };
      
      const badgeClass = apt.status === 'Confirmed' ? 'badge-confirmed' 
        : apt.status === 'Cancelled' ? 'badge-cancelled' 
        : 'badge-pending';

      const canCancel = apt.status === 'Pending' || apt.status === 'Confirmed';

      return `
        <tr>
          <td>
            <div style="font-weight: 700; color: var(--text-main); font-size: 0.95rem;">${doctor.name}</div>
            <div style="font-size: 0.8rem; color: var(--secondary-dark); font-weight: 600;">${doctor.specialization}</div>
          </td>
          <td>
            <div style="font-weight: 600; color: var(--text-main);">${apt.date}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted); font-weight: 500;">${apt.time}</div>
          </td>
          <td>
            <span class="badge ${badgeClass}">${apt.status}</span>
          </td>
          <td>
            <span style="font-size: 0.85rem; color: var(--text-muted);">
              ${apt.notes || 'No symptoms specified.'}
            </span>
          </td>
          <td style="text-align: right;">
            ${canCancel ? `
              <button class="btn btn-danger btn-sm btn-cancel-apt" data-id="${apt.id}">
                Cancel
              </button>
            ` : `
              ${doctor.id ? `
                <a href="#book?doctorId=${doctor.id}" class="btn btn-secondary btn-sm">
                  Book Again
                </a>
              ` : `
                <span style="font-size: 0.8rem; color: var(--text-light);">Archived</span>
              `}
            `}
          </td>
        </tr>
      `;
    }).join('');

    // Attach cancel listeners with async Firestore update
    tbody.querySelectorAll('.btn-cancel-apt').forEach(btn => {
      btn.addEventListener('click', async () => {
        const aptId = btn.dataset.id;
        if (confirm('Are you sure you want to cancel this appointment?')) {
          try {
            btn.disabled = true;
            btn.textContent = 'Updating...';
            await Store.updateAppointmentStatus(aptId, 'Cancelled');
            window.dispatchEvent(new CustomEvent('toast:show', {
              detail: { message: 'Appointment marked as Cancelled in Firestore.', type: 'info' }
            }));
            renderTable();
          } catch (err) {
            window.dispatchEvent(new CustomEvent('toast:show', {
              detail: { message: 'Could not update status: ' + err.message, type: 'error' }
            }));
            btn.disabled = false;
            btn.textContent = 'Cancel';
          }
        }
      });
    });
  };

  statusFilter?.addEventListener('change', renderTable);

  // Live real-time Firestore sync listener
  const storeHandler = () => renderTable();
  window.addEventListener('store:updated', storeHandler);

  renderTable();
}

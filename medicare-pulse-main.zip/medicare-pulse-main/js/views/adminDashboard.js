import { Store } from '../store.js';
import { Auth } from '../auth.js';

export function renderAdminDashboard() {
  const user = Auth.getCurrentUser();

  if (!user || user.role !== 'admin') {
    return `
      <div class="container" style="text-align: center; padding: 4rem 1rem;">
        <div style="font-size: 3rem; margin-bottom: 1rem;">🛡️</div>
        <h2 style="font-size: 1.75rem; font-weight: 800; margin-bottom: 0.5rem;">Administrator Access Only</h2>
        <p style="color: var(--text-muted); margin-bottom: 2rem;">Please sign in with administrator credentials to manage doctors and appointments.</p>
        <a href="#auth" class="btn btn-primary">Go to Admin Login</a>
      </div>
    `;
  }

  const appointments = Store.getAppointments();
  const doctors = Store.getDoctors();
  const patients = Store.getPatients();

  const pendingCount = appointments.filter(a => a.status === 'Pending').length;
  const confirmedCount = appointments.filter(a => a.status === 'Confirmed').length;

  return `
    <div class="container">
      <!-- Admin Header -->
      <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 1rem; margin-bottom: 2rem;">
        <div>
          <div style="font-size: 0.85rem; font-weight: 700; color: var(--accent); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.25rem;">
            Management Console (Connected to Firestore)
          </div>
          <h1 style="font-size: 2.25rem; font-weight: 800; color: var(--text-main);">
            Hospital Admin Portal
          </h1>
          <p style="color: var(--text-muted); font-size: 0.95rem;">
            Moderating appointments, doctors, and scheduling slots in cloud database
          </p>
        </div>

        <div style="display: flex; gap: 0.75rem;">
          <button class="btn btn-primary btn-sm" id="btn-open-add-doc-modal">
            + Add New Doctor
          </button>
        </div>
      </div>

      <!-- Metrics -->
      <div class="dashboard-metrics">
        <div class="metric-card">
          <div class="metric-icon metric-amber">⏳</div>
          <div>
            <div class="metric-val" id="metric-pending">${pendingCount}</div>
            <div class="metric-desc">Pending Approvals</div>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon metric-green">✓</div>
          <div>
            <div class="metric-val" id="metric-confirmed">${confirmedCount}</div>
            <div class="metric-desc">Active / Confirmed</div>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon metric-blue">👨‍⚕️</div>
          <div>
            <div class="metric-val" id="metric-doctors">${doctors.length}</div>
            <div class="metric-desc">Active Doctors</div>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon metric-purple">👥</div>
          <div>
            <div class="metric-val" id="metric-patients">${patients.length}</div>
            <div class="metric-desc">Registered Patients</div>
          </div>
        </div>
      </div>

      <!-- SECTION 1: APPOINTMENTS MODERATION -->
      <div class="table-card">
        <div class="table-header">
          <div>
            <h2 style="font-size: 1.25rem; font-weight: 800; color: var(--text-main);">Appointment Moderation</h2>
            <p style="color: var(--text-muted); font-size: 0.85rem;">Approve, reject, or update patient appointment requests in real time</p>
          </div>

          <div style="display: flex; gap: 0.75rem; align-items: center;">
            <select id="admin-status-filter" class="form-control" style="width: auto; padding: 0.4rem 0.75rem; font-size: 0.85rem;">
              <option value="ALL">All Statuses</option>
              <option value="Pending" selected>Pending Only</option>
              <option value="Confirmed">Confirmed</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>
        </div>

        <div class="table-responsive">
          <table class="custom-table">
            <thead>
              <tr>
                <th>Patient Details</th>
                <th>Doctor & Specialization</th>
                <th>Date & Slot</th>
                <th>Status</th>
                <th>Notes</th>
                <th style="text-align: right;">Moderation Action</th>
              </tr>
            </thead>
            <tbody id="admin-appointments-tbody">
              <!-- Rendered via JS -->
            </tbody>
          </table>
        </div>
      </div>

      <!-- SECTION 2: DOCTOR MANAGEMENT -->
      <div class="table-card" style="margin-top: 3rem;">
        <div class="table-header">
          <div>
            <h2 style="font-size: 1.25rem; font-weight: 800; color: var(--text-main);">Doctor Directory & Available Slots</h2>
            <p style="color: var(--text-muted); font-size: 0.85rem;">Manage specialists and configured consulting hours in Firestore</p>
          </div>

          <button class="btn btn-primary btn-sm" id="btn-open-add-doc-modal-2">
            + Add Specialist
          </button>
        </div>

        <div class="table-responsive">
          <table class="custom-table">
            <thead>
              <tr>
                <th>Doctor</th>
                <th>Specialization</th>
                <th>Experience</th>
                <th>Available Time Slots</th>
                <th style="text-align: right;">Actions</th>
              </tr>
            </thead>
            <tbody id="admin-doctors-tbody">
              <!-- Rendered via JS -->
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Add Doctor Modal -->
    <div id="add-doctor-modal" class="modal-overlay" style="display: none;">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title">Add New Doctor</h3>
          <button class="modal-close" id="modal-doc-close">&times;</button>
        </div>

        <form id="form-add-doctor">
          <div class="form-group">
            <label class="form-label" for="new-doc-name">Doctor Name (with title)</label>
            <input type="text" id="new-doc-name" class="form-control" placeholder="Dr. Jennifer Hall, MD" required />
          </div>

          <div class="form-group">
            <label class="form-label" for="new-doc-spec">Specialization</label>
            <select id="new-doc-spec" class="form-control" required>
              <option value="Cardiology">Cardiology</option>
              <option value="Dermatology">Dermatology</option>
              <option value="Neurology">Neurology</option>
              <option value="Pediatrics">Pediatrics</option>
              <option value="Orthopedics">Orthopedics</option>
              <option value="General Medicine">General Medicine</option>
              <option value="Psychiatry">Psychiatry</option>
              <option value="Ophthalmology">Ophthalmology</option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label" for="new-doc-exp">Years of Experience</label>
            <input type="number" id="new-doc-exp" class="form-control" placeholder="10" min="1" max="50" required value="8" />
          </div>

          <div class="form-group">
            <label class="form-label" for="new-doc-slots">Available Time Slots (Comma-separated)</label>
            <input 
              type="text" 
              id="new-doc-slots" 
              class="form-control" 
              placeholder="09:00 AM, 11:00 AM, 02:00 PM, 04:30 PM" 
              required 
              value="09:00 AM, 10:30 AM, 02:00 PM, 04:00 PM"
            />
            <span style="font-size: 0.8rem; color: var(--text-muted); margin-top: 0.25rem;">
              Separate slots using commas. Example: 09:00 AM, 11:30 AM, 03:00 PM
            </span>
          </div>

          <div class="form-group">
            <label class="form-label" for="new-doc-bio">Short Bio</label>
            <textarea id="new-doc-bio" class="form-control" rows="2" placeholder="Brief clinical background..."></textarea>
          </div>

          <div style="display: flex; gap: 0.75rem; justify-content: flex-end; margin-top: 1.5rem;">
            <button type="button" class="btn btn-secondary" id="modal-doc-cancel">Cancel</button>
            <button type="submit" class="btn btn-primary" id="btn-save-doc-submit">Save Doctor to Cloud</button>
          </div>
        </form>
      </div>
    </div>
  `;
}

export function initAdminDashboardEvents() {
  const user = Auth.getCurrentUser();
  if (!user || user.role !== 'admin') return;

  const aptTbody = document.getElementById('admin-appointments-tbody');
  const docTbody = document.getElementById('admin-doctors-tbody');
  const statusFilter = document.getElementById('admin-status-filter');
  const addDocModal = document.getElementById('add-doctor-modal');

  const openModal = () => { addDocModal.style.display = 'flex'; };
  const closeModal = () => { addDocModal.style.display = 'none'; };

  document.getElementById('btn-open-add-doc-modal')?.addEventListener('click', openModal);
  document.getElementById('btn-open-add-doc-modal-2')?.addEventListener('click', openModal);
  document.getElementById('modal-doc-close')?.addEventListener('click', closeModal);
  document.getElementById('modal-doc-cancel')?.addEventListener('click', closeModal);

  // Render Appointments
  const renderAppointments = () => {
    if (!aptTbody) return;
    const filter = statusFilter ? statusFilter.value : 'ALL';
    let appointments = Store.getAppointments();

    // Update dynamic metric counters
    const pendingCount = appointments.filter(a => a.status === 'Pending').length;
    const confirmedCount = appointments.filter(a => a.status === 'Confirmed').length;
    const elPending = document.getElementById('metric-pending');
    const elConfirmed = document.getElementById('metric-confirmed');
    const elDoctors = document.getElementById('metric-doctors');
    const elPatients = document.getElementById('metric-patients');

    if (elPending) elPending.textContent = pendingCount;
    if (elConfirmed) elConfirmed.textContent = confirmedCount;
    if (elDoctors) elDoctors.textContent = Store.getDoctors().length;
    if (elPatients) elPatients.textContent = Store.getPatients().length;

    if (filter !== 'ALL') {
      appointments = appointments.filter(a => a.status === filter);
    }

    if (appointments.length === 0) {
      aptTbody.innerHTML = `
        <tr>
          <td colspan="6" style="text-align: center; padding: 2.5rem; color: var(--text-muted);">
            No appointments found for filter "${filter}".
          </td>
        </tr>
      `;
      return;
    }

    aptTbody.innerHTML = appointments.map(apt => {
      const patient = Store.getUserById(apt.patientId) || { name: 'Patient (ID: ' + (apt.patientId || '').slice(0, 5) + ')', email: '' };
      const doctor = Store.getDoctorById(apt.doctorId) || { name: 'Doctor Removed', specialization: 'N/A' };

      const badgeClass = apt.status === 'Confirmed' ? 'badge-confirmed'
        : apt.status === 'Cancelled' ? 'badge-cancelled'
        : 'badge-pending';

      return `
        <tr>
          <td>
            <div style="font-weight: 700; color: var(--text-main);">${patient.name}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">${patient.email || 'Registered User'}</div>
          </td>
          <td>
            <div style="font-weight: 600; color: var(--text-main);">${doctor.name}</div>
            <div style="font-size: 0.8rem; color: var(--secondary-dark); font-weight: 600;">${doctor.specialization}</div>
          </td>
          <td>
            <div style="font-weight: 600; color: var(--text-main);">${apt.date}</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">${apt.time}</div>
          </td>
          <td>
            <span class="badge ${badgeClass}">${apt.status}</span>
          </td>
          <td>
            <span style="font-size: 0.825rem; color: var(--text-muted); max-width: 180px; display: inline-block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${apt.notes || ''}">
              ${apt.notes || '—'}
            </span>
          </td>
          <td style="text-align: right;">
            <div style="display: inline-flex; gap: 0.4rem;">
              ${apt.status === 'Pending' ? `
                <button class="btn btn-success btn-sm btn-action-confirm" data-id="${apt.id}" title="Approve & Confirm">
                  Approve
                </button>
                <button class="btn btn-danger btn-sm btn-action-cancel" data-id="${apt.id}" title="Reject & Cancel">
                  Reject
                </button>
              ` : apt.status === 'Confirmed' ? `
                <button class="btn btn-danger btn-sm btn-action-cancel" data-id="${apt.id}">
                  Cancel
                </button>
              ` : `
                <button class="btn btn-secondary btn-sm btn-action-confirm" data-id="${apt.id}">
                  Re-open
                </button>
              `}
            </div>
          </td>
        </tr>
      `;
    }).join('');

    // Attach actions with async Firestore update
    aptTbody.querySelectorAll('.btn-action-confirm').forEach(btn => {
      btn.addEventListener('click', async () => {
        try {
          btn.disabled = true;
          await Store.updateAppointmentStatus(btn.dataset.id, 'Confirmed');
          window.dispatchEvent(new CustomEvent('toast:show', {
            detail: { message: 'Appointment Confirmed in Firestore.', type: 'success' }
          }));
          renderAppointments();
        } catch (e) {
          window.dispatchEvent(new CustomEvent('toast:show', {
            detail: { message: 'Update failed: ' + e.message, type: 'error' }
          }));
          btn.disabled = false;
        }
      });
    });

    aptTbody.querySelectorAll('.btn-action-cancel').forEach(btn => {
      btn.addEventListener('click', async () => {
        try {
          btn.disabled = true;
          await Store.updateAppointmentStatus(btn.dataset.id, 'Cancelled');
          window.dispatchEvent(new CustomEvent('toast:show', {
            detail: { message: 'Appointment marked as Cancelled.', type: 'info' }
          }));
          renderAppointments();
        } catch (e) {
          window.dispatchEvent(new CustomEvent('toast:show', {
            detail: { message: 'Update failed: ' + e.message, type: 'error' }
          }));
          btn.disabled = false;
        }
      });
    });
  };

  // Render Doctors
  const renderDoctors = () => {
    if (!docTbody) return;
    const doctors = Store.getDoctors();

    docTbody.innerHTML = doctors.map(doc => `
      <tr>
        <td>
          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <div class="doctor-avatar" style="width: 40px; height: 40px; font-size: 1rem;">${doc.avatar || 'DR'}</div>
            <strong style="color: var(--text-main);">${doc.name}</strong>
          </div>
        </td>
        <td>
          <span class="doctor-spec">${doc.specialization}</span>
        </td>
        <td>
          <span style="font-size: 0.875rem; color: var(--text-muted);">${doc.experienceYears || 5} yrs</span>
        </td>
        <td>
          <div style="display: flex; flex-wrap: wrap; gap: 0.3rem;">
            ${(doc.availableSlots || []).map(s => `<span class="slot-tag">${s}</span>`).join('')}
          </div>
        </td>
        <td style="text-align: right;">
          <button class="btn btn-danger btn-sm btn-delete-doc" data-id="${doc.id}">
            Remove
          </button>
        </td>
      </tr>
    `).join('');

    docTbody.querySelectorAll('.btn-delete-doc').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (confirm('Are you sure you want to remove this doctor from Firestore?')) {
          try {
            btn.disabled = true;
            await Store.deleteDoctor(btn.dataset.id);
            window.dispatchEvent(new CustomEvent('toast:show', {
              detail: { message: 'Doctor profile removed from cloud.', type: 'info' }
            }));
            renderDoctors();
          } catch (e) {
            window.dispatchEvent(new CustomEvent('toast:show', {
              detail: { message: 'Could not remove doctor: ' + e.message, type: 'error' }
            }));
            btn.disabled = false;
          }
        }
      });
    });
  };

  // Handle Add Doctor Submit
  document.getElementById('form-add-doctor')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const saveBtn = document.getElementById('btn-save-doc-submit');
    const name = document.getElementById('new-doc-name').value.trim();
    const specialization = document.getElementById('new-doc-spec').value;
    const experienceYears = parseInt(document.getElementById('new-doc-exp').value, 10) || 5;
    const rawSlots = document.getElementById('new-doc-slots').value;
    const bio = document.getElementById('new-doc-bio').value.trim();

    const availableSlots = rawSlots.split(',').map(s => s.trim()).filter(Boolean);

    try {
      if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving to Firestore...';
      }

      await Store.saveDoctor({
        name,
        specialization,
        experienceYears,
        availableSlots,
        bio: bio || `Specialist in ${specialization} providing tailored clinical consultations.`
      });

      window.dispatchEvent(new CustomEvent('toast:show', {
        detail: { message: `Doctor ${name} successfully added to Firestore!`, type: 'success' }
      }));

      closeModal();
      e.target.reset();
      renderDoctors();
    } catch (err) {
      window.dispatchEvent(new CustomEvent('toast:show', {
        detail: { message: 'Error adding doctor: ' + err.message, type: 'error' }
      }));
    } finally {
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save Doctor to Cloud';
      }
    }
  });

  statusFilter?.addEventListener('change', renderAppointments);

  // Live real-time Firestore sync listener
  const storeHandler = () => {
    renderAppointments();
    renderDoctors();
  };
  window.addEventListener('store:updated', storeHandler);

  renderAppointments();
  renderDoctors();
}

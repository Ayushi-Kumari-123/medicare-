import { Store } from '../store.js';

export function renderHome() {
  const doctors = Store.getDoctors().slice(0, 3);
  const specialties = ['All', 'Cardiology', 'Dermatology', 'Neurology', 'Pediatrics', 'Orthopedics', 'General Medicine'];

  return `
    <div class="container">
      <!-- Hero Section -->
      <section class="hero-wrapper">
        <div class="hero-text-col">
          <div class="hero-pill">
            <span>✨</span> Next-Gen Healthcare Scheduling
          </div>
          <h1 class="hero-title">
            Book Top-Rated <span class="gradient-text">Doctors</span> With Zero Wait Time.
          </h1>
          <p class="hero-desc">
            Connect with board-certified medical specialists, browse available time slots in real time, and manage your family's health appointments effortlessly.
          </p>
          <div class="hero-actions">
            <a href="#doctors" class="btn btn-primary btn-lg" id="hero-find-doctors-btn">
              Find Doctors & Book
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </a>
            <a href="#auth" class="btn btn-secondary btn-lg" id="hero-join-btn">
              Patient Portal
            </a>
          </div>

          <!-- Quick Search Bar -->
          <div style="margin-top: 2rem; background: #ffffff; padding: 0.6rem; border-radius: var(--radius-md); border: 1px solid var(--border-color); display: flex; gap: 0.5rem; box-shadow: var(--shadow-sm); max-width: 500px;">
            <input type="text" id="home-quick-search" placeholder="Search by doctor name or specialty..." class="form-control" style="border: none; padding: 0.5rem 0.75rem;" />
            <button class="btn btn-primary btn-sm" id="home-search-btn" style="padding: 0.5rem 1rem;">
              Search
            </button>
          </div>
        </div>

        <div class="hero-media-col">
          <div class="hero-image-card">
            <img src="assets/images/hero_banner.jpg" alt="Healthcare medical consultation" />
          </div>
        </div>
      </section>

      <!-- Stats Banner -->
      <div class="hero-stats-banner">
        <div class="stat-item">
          <span class="stat-number">12,500+</span>
          <span class="stat-label">Appointments Successfully Scheduled</span>
        </div>
        <div class="stat-item">
          <span class="stat-number">50+</span>
          <span class="stat-label">Verified Specialists & Physicians</span>
        </div>
        <div class="stat-item">
          <span class="stat-number">99.2%</span>
          <span class="stat-label">Positive Patient Satisfaction Rate</span>
        </div>
      </div>

      <!-- Specialties Section -->
      <section class="section-header">
        <h2 class="section-title">Explore by Medical Specialty</h2>
        <p class="section-subtitle">Find dedicated specialists tailored to your specific health requirements</p>
      </section>

      <div class="specialty-chips" id="home-specialty-chips">
        ${specialties.map(spec => `
          <a href="#doctors?specialty=${encodeURIComponent(spec === 'All' ? '' : spec)}" class="specialty-chip">
            ${spec}
          </a>
        `).join('')}
      </div>

      <!-- Featured Doctors Section -->
      <section class="section-header" style="margin-top: 2rem;">
        <h2 class="section-title">Featured Doctors Available This Week</h2>
        <p class="section-subtitle">Verified clinical profiles with convenient appointment slots</p>
      </section>

      <div class="doctor-grid">
        ${doctors.map(doc => `
          <div class="doctor-card">
            <div class="doctor-card-top">
              <div class="doctor-avatar">${doc.avatar || 'DR'}</div>
              <div class="doctor-meta">
                <h3>${doc.name}</h3>
                <span class="doctor-spec">${doc.specialization}</span>
                <div class="doctor-rating">★ ${doc.rating.toFixed(1)} (${doc.experienceYears}+ years exp)</div>
              </div>
            </div>

            <p style="font-size: 0.875rem; color: var(--text-muted); margin-bottom: 1rem; line-height: 1.4;">
              ${doc.bio}
            </p>

            <div class="doctor-slots-title">Available Consultation Slots:</div>
            <div class="slot-tags">
              ${doc.availableSlots.slice(0, 4).map(slot => `<span class="slot-tag">${slot}</span>`).join('')}
              ${doc.availableSlots.length > 4 ? `<span class="slot-tag">+${doc.availableSlots.length - 4} more</span>` : ''}
            </div>

            <div class="doctor-card-footer">
              <span style="font-size: 0.85rem; font-weight: 700; color: var(--secondary-dark);">
                ✓ Online Booking Open
              </span>
              <a href="#book?doctorId=${doc.id}" class="btn btn-primary btn-sm" id="book-doc-${doc.id}">
                Book Now
              </a>
            </div>
          </div>
        `).join('')}
      </div>

      <!-- How It Works Section -->
      <section style="margin-top: 5rem; padding: 3rem; background: #ffffff; border-radius: var(--radius-lg); border: 1px solid var(--border-color); box-shadow: var(--shadow-sm); text-align: center;">
        <h2 class="section-title" style="margin-bottom: 0.75rem;">How MediCare Works</h2>
        <p class="section-subtitle" style="margin-bottom: 3rem;">Three easy steps to your upcoming consultation</p>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 2rem;">
          <div style="padding: 1.5rem;">
            <div style="width: 52px; height: 52px; background: var(--primary-light); color: var(--primary); border-radius: var(--radius-full); display: flex; align-items: center; justify-content: center; margin: 0 auto 1.25rem; font-size: 1.5rem; font-weight: 800;">1</div>
            <h3 style="font-size: 1.15rem; font-weight: 700; margin-bottom: 0.5rem;">Select Your Doctor</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Browse vetted physicians by specialty, ratings, and clinical background.</p>
          </div>
          <div style="padding: 1.5rem;">
            <div style="width: 52px; height: 52px; background: var(--secondary-light); color: var(--secondary-dark); border-radius: var(--radius-full); display: flex; align-items: center; justify-content: center; margin: 0 auto 1.25rem; font-size: 1.5rem; font-weight: 800;">2</div>
            <h3 style="font-size: 1.15rem; font-weight: 700; margin-bottom: 0.5rem;">Pick A Free Time Slot</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Select an available calendar date and direct slot that fits your schedule.</p>
          </div>
          <div style="padding: 1.5rem;">
            <div style="width: 52px; height: 52px; background: var(--accent-light); color: var(--accent); border-radius: var(--radius-full); display: flex; align-items: center; justify-content: center; margin: 0 auto 1.25rem; font-size: 1.5rem; font-weight: 800;">3</div>
            <h3 style="font-size: 1.15rem; font-weight: 700; margin-bottom: 0.5rem;">Instant Confirmation</h3>
            <p style="color: var(--text-muted); font-size: 0.9rem;">Track your appointment status live through your patient dashboard.</p>
          </div>
        </div>
      </section>
    </div>
  `;
}

export function initHomeEvents() {
  const searchInput = document.getElementById('home-quick-search');
  const searchBtn = document.getElementById('home-search-btn');

  const executeSearch = () => {
    const val = searchInput?.value.trim();
    if (val) {
      window.location.hash = `#doctors?search=${encodeURIComponent(val)}`;
    } else {
      window.location.hash = '#doctors';
    }
  };

  searchBtn?.addEventListener('click', executeSearch);
  searchInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') executeSearch();
  });
}

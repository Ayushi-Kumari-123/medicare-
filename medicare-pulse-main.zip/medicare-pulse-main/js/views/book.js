import { Store } from '../store.js';
import { Auth } from '../auth.js';

export function renderBookAppointment(doctorId) {
  const doctor = Store.getDoctorById(doctorId);

  if (!doctor) {
    return `
      <div class="container" style="text-align: center; padding: 4rem 1rem;">
        <h2>Doctor Not Found</h2>
        <p style="color: var(--text-muted); margin: 1rem 0 2rem;">The doctor you selected could not be found or has been updated.</p>
        <a href="#doctors" class="btn btn-primary">Browse All Doctors</a>
      </div>
    `;
  }

  // Minimum date: today or tomorrow
  const today = new Date();
  const minDate = today.toISOString().split('T')[0];
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const defaultDate = tomorrow.toISOString().split('T')[0];

  const currentUser = Auth.getCurrentUser();
  const isPatientLoggedIn = Auth.isPatient();

  return `
    <div class="container">
      <div style="margin-bottom: 2rem;">
        <a href="#doctors" style="color: var(--primary); font-weight: 600; display: inline-flex; align-items: center; gap: 0.4rem; margin-bottom: 0.75rem;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
          Back to Doctors
        </a>
        <h1 style="font-size: 2.25rem; font-weight: 800; color: var(--text-main);">
          Book an Appointment
        </h1>
        <p style="color: var(--text-muted); font-size: 1rem;">
          Confirm your consultation details with ${doctor.name}
        </p>
      </div>

      <div class="booking-layout">
        <!-- Doctor Info Sidebar -->
        <div class="booking-summary-card">
          <div style="text-align: center; margin-bottom: 1.5rem;">
            <div class="doctor-avatar" style="width: 80px; height: 80px; margin: 0 auto 1rem; font-size: 2rem;">
              ${doctor.avatar || 'DR'}
            </div>
            <h2 style="font-size: 1.25rem; font-weight: 800; margin-bottom: 0.25rem;">${doctor.name}</h2>
            <span class="doctor-spec">${doctor.specialization}</span>
            <div class="doctor-rating" style="margin-top: 0.4rem;">
              ★ ${(doctor.rating || 4.9).toFixed(1)} (${doctor.experienceYears || 10}+ Years Clinical Experience)
            </div>
          </div>

          <div style="border-top: 1px solid var(--border-color); padding-top: 1.25rem; font-size: 0.875rem; color: var(--text-muted); line-height: 1.5;">
            <p style="margin-bottom: 0.75rem;">
              <strong style="color: var(--text-main);">About:</strong> ${doctor.bio}
            </p>
            <p style="margin-bottom: 0.5rem;">
              <strong style="color: var(--text-main);">Consultation Mode:</strong> In-Person & Telehealth
            </p>
            <p>
              <strong style="color: var(--text-main);">Status:</strong> <span style="color: var(--status-confirmed); font-weight: 700;">● Accepting New Patients</span>
            </p>
          </div>
        </div>

        <!-- Booking Form -->
        <div class="booking-form-card">
          ${!isPatientLoggedIn ? `
            <div style="background: var(--primary-light); border: 1px solid #bae6fd; border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 2rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
              <div>
                <strong style="color: var(--primary-dark); font-size: 0.95rem; display: block; margin-bottom: 0.25rem;">Sign In Required to Complete Booking</strong>
                <p style="color: #0369a1; font-size: 0.85rem; margin: 0;">Please log in or register your patient account to reserve your slot.</p>
              </div>
              <a href="#auth" class="btn btn-primary btn-sm" id="book-login-redirect-btn">
                Log In / Register
              </a>
            </div>
          ` : `
            <div style="background: #f1f5f9; border-radius: var(--radius-md); padding: 0.85rem 1.25rem; margin-bottom: 1.75rem; display: flex; align-items: center; justify-content: space-between;">
              <span style="font-size: 0.875rem; color: var(--text-muted);">
                Booking as: <strong style="color: var(--text-main);">${currentUser.name}</strong> (${currentUser.email})
              </span>
              <span class="user-badge-role">Verified Patient</span>
            </div>
          `}

          <form id="appointment-booking-form">
            <!-- Step 1: Select Date -->
            <div class="form-group">
              <label class="form-label" for="booking-date">
                1. Select Consultation Date
              </label>
              <input 
                type="date" 
                id="booking-date" 
                class="form-control" 
                min="${minDate}" 
                value="${defaultDate}" 
                required 
              />
              <span style="font-size: 0.8rem; color: var(--text-muted); margin-top: 0.25rem;">
                Select a valid date to view available time slots.
              </span>
            </div>

            <!-- Step 2: Time Slots -->
            <div class="form-group" style="margin-top: 1.5rem;">
              <label class="form-label">
                2. Select Available Time Slot
              </label>
              <div id="booking-slot-grid" class="slot-picker-grid">
                <!-- Dynamically populated -->
              </div>
              <input type="hidden" id="selected-time-slot" required />
            </div>

            <!-- Step 3: Notes -->
            <div class="form-group" style="margin-top: 1.5rem;">
              <label class="form-label" for="booking-notes">
                3. Reason for Visit / Medical Notes (Optional)
              </label>
              <textarea 
                id="booking-notes" 
                class="form-control" 
                rows="3" 
                placeholder="Briefly describe your symptoms or reason for scheduling..."
              ></textarea>
            </div>

            <!-- Submission Area -->
            <div style="margin-top: 2rem; border-top: 1px solid var(--border-color); padding-top: 1.5rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
              <div>
                <div style="font-size: 0.85rem; color: var(--text-muted);">Initial Appointment Status:</div>
                <span class="badge badge-pending">Pending Admin / Doctor Approval</span>
              </div>

              <button 
                type="submit" 
                class="btn btn-primary btn-lg" 
                id="confirm-booking-btn"
                ${!isPatientLoggedIn ? 'disabled title="Please log in as a patient first"' : ''}
              >
                Confirm Appointment Request
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;
}

export function initBookAppointmentEvents(doctorId) {
  const doctor = Store.getDoctorById(doctorId);
  if (!doctor) return;

  const dateInput = document.getElementById('booking-date');
  const slotGrid = document.getElementById('booking-slot-grid');
  const selectedSlotInput = document.getElementById('selected-time-slot');
  const form = document.getElementById('appointment-booking-form');
  const confirmBtn = document.getElementById('confirm-booking-btn');

  const updateSlots = () => {
    if (!slotGrid || !dateInput) return;
    const selectedDate = dateInput.value;
    if (!selectedDate) {
      slotGrid.innerHTML = '<p style="color: var(--text-muted); font-size: 0.9rem;">Please select a date first.</p>';
      return;
    }

    const availableSlots = doctor.availableSlots || [];
    if (availableSlots.length === 0) {
      slotGrid.innerHTML = '<p style="color: var(--text-muted); font-size: 0.9rem;">No slots configured for this doctor.</p>';
      return;
    }

    slotGrid.innerHTML = availableSlots.map(slot => {
      const isBooked = Store.isSlotBooked(doctor.id, selectedDate, slot);
      return `
        <button 
          type="button" 
          class="slot-btn ${isBooked ? 'disabled' : ''}" 
          data-slot="${slot}" 
          ${isBooked ? 'disabled title="Slot already booked for this date"' : ''}
        >
          ${slot}
          ${isBooked ? '<span style="display:block; font-size:0.65rem; color:var(--status-cancelled);">Booked</span>' : ''}
        </button>
      `;
    }).join('');

    // Attach slot click listener
    slotGrid.querySelectorAll('.slot-btn:not(:disabled)').forEach(btn => {
      btn.addEventListener('click', () => {
        slotGrid.querySelectorAll('.slot-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        selectedSlotInput.value = btn.dataset.slot;
      });
    });

    selectedSlotInput.value = '';
  };

  dateInput?.addEventListener('change', updateSlots);
  updateSlots();

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!Auth.isPatient()) {
      sessionStorage.setItem('returnUrl', `#book?doctorId=${doctorId}`);
      window.dispatchEvent(new CustomEvent('toast:show', {
        detail: { message: 'Please log in to your patient account first.', type: 'error' }
      }));
      window.location.hash = '#auth';
      return;
    }

    const date = dateInput.value;
    const time = selectedSlotInput.value;
    const notes = document.getElementById('booking-notes')?.value || '';

    if (!time) {
      window.dispatchEvent(new CustomEvent('toast:show', {
        detail: { message: 'Please select an available time slot.', type: 'error' }
      }));
      return;
    }

    try {
      if (confirmBtn) {
        confirmBtn.disabled = true;
        confirmBtn.textContent = 'Saving to Cloud Firestore...';
      }

      const patient = Auth.getCurrentUser();
      const newApt = await Store.createAppointment({
        patientId: patient.id,
        doctorId: doctor.id,
        date,
        time,
        notes
      });

      window.dispatchEvent(new CustomEvent('toast:show', {
        detail: { message: `Appointment booked in Firestore! Status: ${newApt.status}`, type: 'success' }
      }));

      window.location.hash = '#patient-dashboard';
    } catch (err) {
      window.dispatchEvent(new CustomEvent('toast:show', {
        detail: { message: err.message, type: 'error' }
      }));
      if (confirmBtn) {
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'Confirm Appointment Request';
      }
    }
  });
}
